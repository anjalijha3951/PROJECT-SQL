import java.util.*;

class Disease {
    static int count = 1;
    int id;
    String crop, name, symptoms, treatment;

    Disease(String crop, String name, String symptoms, String treatment) {
        this.id = count++;
        this.crop = crop;
        this.name = name;
        this.symptoms = symptoms;
        this.treatment = treatment;
    }
}

public class Main {
    static List<Disease> diseases = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;

        do {
            System.out.println("\n=== Disease Management System ===");
            System.out.println("1. Add Disease");
            System.out.println("2. View Diseases");
            System.out.println("3. Update Disease");
            System.out.println("4. Delete Disease");
            System.out.println("5. Search by Crop Name");
            System.out.println("0. Exit");
            System.out.print("Choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> addDisease();
                case 2 -> viewDiseases();
                case 3 -> updateDisease();
                case 4 -> deleteDisease();
                case 5 -> searchDisease();
                case 0 -> System.out.println("Goodbye!");
                default -> System.out.println("Invalid choice.");
            }

        } while (choice != 0);
    }

    static void addDisease() {
        System.out.print("Crop: ");
        String crop = sc.nextLine();
        System.out.print("Disease Name: ");
        String name = sc.nextLine();
        System.out.print("Symptoms: ");
        String symptoms = sc.nextLine();
        System.out.print("Treatment: ");
        String treatment = sc.nextLine();
        diseases.add(new Disease(crop, name, symptoms, treatment));
        System.out.println("Disease added.");
    }

    static void viewDiseases() {
        if (diseases.isEmpty()) {
            System.out.println("No diseases found.");
            return;
        }
        for (Disease d : diseases) {
            System.out.println(d.id + ". " + d.crop + " | " + d.name);
        }
    }

    static void updateDisease() {
        System.out.print("Enter ID to update: ");
        int id = sc.nextInt(); sc.nextLine();
        for (Disease d : diseases) {
            if (d.id == id) {
                System.out.print("New Crop: ");
                d.crop = sc.nextLine();
                System.out.print("New Disease: ");
                d.name = sc.nextLine();
                System.out.print("New Symptoms: ");
                d.symptoms = sc.nextLine();
                System.out.print("New Treatment: ");
                d.treatment = sc.nextLine();
                System.out.println("Updated.");
                return;
            }
        }
        System.out.println("Disease not found.");
    }

    static void deleteDisease() {
        System.out.print("Enter ID to delete: ");
        int id = sc.nextInt(); sc.nextLine();
        boolean removed = diseases.removeIf(d -> d.id == id);
        System.out.println(removed ? "Deleted." : "Disease not found.");
    }

    static void searchDisease() {
        System.out.print("Enter crop name: ");
        String crop = sc.nextLine();
        for (Disease d : diseases) {
            if (d.crop.equalsIgnoreCase(crop)) {
                System.out.println("Disease: " + d.name);
                System.out.println("Symptoms: " + d.symptoms);
                System.out.println("Treatment: " + d.treatment);
                return;
            }
        }
        System.out.println("No disease found.");
    }
}
